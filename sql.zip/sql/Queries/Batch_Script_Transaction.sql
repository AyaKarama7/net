use MyDB
--start of batch
select * from Employee
update Employee set Salary+=100
delete  from Employee where SSN=50
--end of batch

--start
create rule r1 as @x>1000
sp_bindrule r1,'Employee.Salary'
--can't run in the same batch
--end

--start of script
create rule r1 as @x>1000
go
sp_bindrule r1,'Employee.Salary'
--end of script

--transaction
create table parent(pid int primary key)
create table child(cid int foreign key references parent(pid))

begin transaction
insert into parent values(1)
insert into parent values(2)
insert into parent values(3)
commit
--here you can find that 3 rows have been added to parent 
--as you commit the changes

begin transaction
insert into child values(1)
insert into child values(2)
insert into child values(3)
rollback
--here you can find that no rows have been added 
--as you did't commit changes
--like when you upload files to githup you should 
--commit them for them to be saved in your account

begin transaction
insert into child values(1)
insert into child values(5)
insert into child values(3)
commit
--like a normal batch

begin transaction
insert into child values(1)
insert into child values(5)
insert into child values(3)
rollback
--like a normal batch

truncate table child
--to handle transaction exceptions use:
begin try
begin transaction
insert into child values(1)
insert into child values(5)
insert into child values(3)
commit
end try
begin catch
rollback
end catch
--Null added to child
--in this way we met the slogan of transaction
--"�� ���� ���� �� �� ���� ���� ����"
--compare this with 2 last transactions 
--we can say that try..catch make transaction
--to be like a single unit of work
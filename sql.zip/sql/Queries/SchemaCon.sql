use MyDB
select USER_NAME()
select * from aya.Employee
insert into aya.Employee 
values(13,'wesam','salem','m','7-7-2000',30,2,24567,24)
update aya.Employee set Age=1 --has no permission to update 

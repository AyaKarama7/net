use SD
select * from Emolyee
select * from Project
insert into Project(Pnum,Pname) values(40,'xyz')
select * from Project
---------------------------------------------------------------
--DDL(create,alter,drop,add)
Create table emp
(
 eid int Primary Key,
 ename varchar(20) not null,  
 eage int,
 eadd varchar(20) default('Cairo'),
 hiredate date default getdate(), --current system date as a default
 dnum int
)
alter table emp add salary int
alter table emp alter column salary bigint 
alter table emp drop column salary --delete column 
alter table emp add Fname varchar(20),Lname varchar(20)
drop table emp --remove table with its structure (Data&metadata)
----------------------------------------------------------------
--DML(insert,update,delete)
insert into emp values(1,'Aya',NULL,'Minya','1/1/2001',NULL)
insert into emp(ename,eid) values('Eman',2)
--insert constructor
insert into emp(ename,eid)values('omnia',3),('mo',4),('ali',5)

update emp set ename='Omar' , eage=20 where eid=4  --without where all enames will be updated to 'Omar'
update emp set eage+=1 --add 1 to all eages
update emp set eadd=NULL --delete data from column
update emp set Fname=ename 
update emp set Lname='Karamah'
update emp set Lname='Ahmed' where eid=2 or eid=3
delete from emp where eid=1
delete from emp --remove all  rows in emp but the table structure "emp" still exist
-------------------------------------------------------------------
--DQL
select * from emp 
select eid,ename from emp --select columns
select ename,eid from emp where eage>20 --select rows
select * from emp order by ename asc  --default ascending 
select * from emp order by ename 
select * from emp order by ename desc -- has no effect on the data on the hard disk
select Fname+' '+Lname as fullname from emp  --alias name
select Fname+' '+Lname fullname from emp
select Fname+' '+Lname [full name] from emp --space
--select * from emp where eage!=NULL --wrong statement
select * from emp where eage is not null
select * from emp where eage is null
select distinct Lname from emp --sort and remove duplication 
select * from emp where ename in('Aya','Eman','Ali') -- Aya or ali or Eman
select * from emp where eage>=20 and eage<=25
select * from emp where eage between 20 and 25 


use MyDB
create table Employee
(
 SSN int primary key,
 Fname varchar(20) not null,
 Lname varchar(20) ,
 Gender char ,
 BD date,
 Dnum int,
 Mid int
)
create table Department
(
 Dnum int primary key,
 Dname varchar(20) not null,
 MSSN int,
 hiredate date 
)
create table Loc
(
 Dnum int ,
 loc varchar(20)
)
create table Project
(
 Pnum int primary key,
 Pname varchar(20) not null,
 City varchar(20) default 'Cairo',
 Dnum int
)
create table Depend
(
 SSN int,
 Dname varchar(20) not null,
 Gender char not null,
 BD date
)
create table Work
(
 SSN int,
 Pnum int,
 Hours date
)
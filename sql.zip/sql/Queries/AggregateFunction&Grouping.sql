use MyDB
alter table Employee add Salary int
select Max(Salary)as "Max" ,MIN(Salary)as "Min" from Employee
select COUNT(SSN) from Employee
select Count(*) from Employee
select count(Lname)from Employee  -- did not count null
select avg(Salary)from Employee
update Employee set Salary=NULL where SSN=1
select Salary from Employee where SSN=1
select avg(Salary)from Employee  --don't count null values or sum them
select sum(Salary)/count(*) from Employee --smaller value as it counts null
select avg(isnull(Salary,0))from Employee 
-- the same as previous
--counts null
--faster than previous as the previous one contain 2 aggrgates
select min(Salary),Dnum from Employee --Error & don't know how to work so you need grouping
select min(Salary),Dnum from Employee group by Dnum
select count(SSN),Gender from Employee where Dnum in(10,40) group by Gender
--from-->where-->group-->select 
--from Employee group the table by gender if Dnum=10 or 30 count its ssn 
select sum(Salary),Dnum from Employee where sum(Salary)>=10000 group by Dnum 
--Aggregate function can't appear in where 
select sum(Salary),Dnum from Employee group by Dnum having sum(Salary)>=10000
--Aggregate function can appear in having 
--having do the same work of where
--where is a condition for rows 
--having is a condition for group
select sum(Salary),E.Dnum ,D.Dname from Employee E inner join Department D 
on D.Dnum=E.Dnum group by E.Dnum,D.Dname 
--all columns you select should be exist in group by
--group by Dnum and Dname
--(20,is) is a group and (50,is) is another group
select sum(Salary) from Employee having count(SSN)>5
--having can appear without group by when there is only aggregate
--functions in the select statement
select * from Employee having count(SSN)>5
--Error as it needs grouping as we have aggregate and column








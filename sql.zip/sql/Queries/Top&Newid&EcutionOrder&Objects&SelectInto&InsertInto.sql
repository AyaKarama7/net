use MyDB
select top(3) * from Employee 
select top(13) * from Employee
select top(3) Fname from Employee where Gender='m'
--first 3 males' Fname
select top(2) Salary from Employee order by Salary desc
--max 2 salaries
select top(6) with ties * from Employee order by Age
--output 7 rows??!
--top() with ties should take order by
--if you order employees by age like this (1,2,3,4,4,4)
--if you select top 4 rows top with ties select 6 rows
--as it select also equals 
--only in tail
select top(10) with ties * from Employee order by Age
select newid() 
--return glopal universal id 
--return random diffrent id in evrey run 
select *,newid() from Employee
--give unique id for each employee at one run
select top(3) * from Employee order by newid()
--at evrey run it return diffrent 3 random employees 
--randomize data 
--------------------------------------------------------
--Excution
select Fname+' '+Lname as FullName from Employee order by FullName
select Fname+' '+Lname as FullName from Employee 
where FullName='nada ali' --Error
select * from
(select Fname+' '+Lname as FullName from Employee)as  NewTable
where FullName='nada ali' --solution
---------------------------------------------------------
--DB objects
select * from Employee 
select * from [DESKTOP-6571O88\SQLEXPRESS].[MyDB].[dbo].Employee
--the same as previous query as the engine take all data except
--object name when connecting DB so it know them 
select * from [DESKTOP-6571O88\SQLEXPRESS].[SD].[dbo].Project
--select object from another DB
select SSN from Employee 
union all 
select Pnum from [DESKTOP-6571O88\SQLEXPRESS].[SD].[dbo].Project
-----------------------------------------------------------------
--Select..into
select Fname into table1 from Employee
--DDL query 
--create new table in DB called table1
--copy Fname fom Employee to table1
--can't run this query more than once as the pk can't repeat 
--you already create the table so you can't repeat it
select Fname into [SD].[dbo].table1
from Employee
--copy and paste table in another DB
select Fname,Gender into [SD].[dbo].table2
from Employee where 1=2
--create only structure as the condition is false Fname!=Gender
--no data exist in the table 
insert into [SD].[dbo].table2 select Fname,Gender from Employee
--insert based on select 
--take data from table but leave structure

select * from [SD].[dbo].table2

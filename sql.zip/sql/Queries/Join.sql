use SD1
use MyDB
create table Department
(
 Did int primary key,
 Dname varchar(50) not null
)
insert into Department values(10,'SD'),(20,'HR'),(30,'IS'),(40,'Admin')
select * from Department
select * from Student
select Sname,Dname from Student,Department
--output the cartesian product of all rows of 2 columns
--output all possible compinations of rows
--output each sname with each dname
--not used by developers but can be used in testing
select Sname,Dname from Student cross join Department
--the same as previous query 
select Sname,Dname from Student,Department where Department.Did=Student.Did
--Equi Join
--We used Department. & Student. as PK is the same name as FK
--ANSI  SQL syntax
select Sname,Dname from Student S,Department D where D.Did=S.Did
--the same as previous query only used alias
select Sname,Dname from Student S inner join Department D on D.Did=S.Did
--the same as previous query 
--Transact SQL sentax
select Sname,Dname from Student S left outer join Department D on D.Did=S.Did
--output all stuedents even if they have department or no
select Sname,Dname from Student S right outer join Department D on D.Did=S.Did
--output all departments even if they are students in or not
select Sname,Dname from Student S full outer join Department D on D.Did=S.Did
--output inner join data
--output left join data
--output right join data
create table Employee
(
 Eid int primary key,
 Ename varchar(50) not null,
 Mid int
)
insert into Employee values(1,'ahmed',NULL),(2,'omar',1),(3,'eman',1),(4,'nada',2)
select x.Ename as EmpName,y.Ename as Manager from 
Employee x,Employee y where x.Mid=y.Eid
--self join
--x = child has FK  Employee
--y = parent has PK Manager 
--for(int i=0;i<x.size;i++)
---EmpName=x.ename
---for(int j=0;j<y.size();j++)
----if(x.Mid[i]==y.Eid[j]) put y.ename in Manager
--like changing each FK in the child with equal ename 
select x.Ename,y.* from Employee x , Employee y where x.Mid=y.Eid
--join multi tables
select Fname,Dname,Pname from Employee E,Department D,Project P
where E.Dnum=D.Dnum and D.Dnum=P.Dnum
select Fname,Dname,Pname from Employee E inner join Department D
on E.Dnum=D.Dnum inner join Project P on D.Dnum=P.Dnum
--the same as previous syntax  
select Fname,Dname,Pname,W.* from Employee E inner join Department D
on E.Dnum=D.Dnum inner join Project P on D.Dnum=P.Dnum inner join Work W
on W.Pnum=P.Pnum
alter table Employee add Salary int
update Employee set Salary=5000
--Join with DML
--increase all Employees' salary with 1000
update Employee set Salary+=1000
--increase all Employees' salary work in "it" department with 1000
select Salary , Dname from Employee E,Department D where E.Dnum=D.Dnum and D.Dname='it'
update Employee set Salary+=1000 
from Employee E,Department D where E.Dnum=D.Dnum and D.Dname='it'


use MyDB
--replace null with a value
select Lname from Employee
select isnull(Lname,' ') from Employee
select isnull(Lname,'NO Name') from Employee
select isnull(Lname,Fname) as NewName from Employee
--replace with multipe values
select coalesce(Lname,Fname,'*') from Employee
--if there isn't Lname output Fname
--if thete isn't Fname output *
--take array of values
--select statement is memoriwize-->not affect DB
--concate 2 columns of diffrent datatypes 
select Fname+' '+convert(varchar(2),Dnum) from Employee
select 'FName= '+Fname+' &age= '+convert(varchar(2),Dnum) from Employee
--Null in any operation result in Null
select isnull(Fname,' ')+' '+convert(varchar(2),isnull(Dnum,0)) from Employee
--complicated statement!!!!!
select concat(Fname,' ',Dnum)from Employee
--the same as previous syntax but less complicate
--replace Null with ' '
select concat(Lname,' ',Dnum)from Employee

select * from Employee where Lname like 'ahmed' --ahmed,Ahmed,AHMED,aHmed..
--_:one char    %:zero or more char
select * from Employee where Lname like '_hmed' 
select * from Employee where Lname like '%a%' 
select * from Employee where Lname like '_a%'
--[]:or
select * from Employee where Lname like '[am]%' --start with a or m then any num of chars
select * from Employee where Lname like '[^am]%' --start with any char except a and m 
select * from Employee where Lname like '[a-l]%' --start with any char in range from a to l 
select * from Employee where Lname like '[^a-l]%' --start with any char except range a:l
select * from Employee where Lname like '%[%]' --end with %
select * from Employee where Lname like '[_]%' --start with _
select * from Employee where Lname like '%[_]%'--contain _
select * from Employee where Lname like '%[_]'--end with _

select Fname,Lname from Employee order by Dnum
select Fname,Lname from Employee order by 2 --sort by column number 2 in select=Lname
select Fname,Lname from Employee order by Dnum,Fname desc
--sort by Dnum asc by default
--if 2 elements have the same dnum sort by Fname desc
select year(getdate())
select month(getdate())
select day(getdate())
select SUBSTRING(Fname,1,3) from Employee
select DB_NAME() --Databse name
select SUSER_NAME() --name of user of server



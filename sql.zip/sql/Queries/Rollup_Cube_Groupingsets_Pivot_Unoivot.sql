use MyDB
create table sales(Pid int,Quantity int)
alter table sales add SalesMan varchar(50)
--select total sales for each product and total sales
select Pid as 'Pid' , sum(Quantity) from sales group by Pid 
union all 
select 0,sum(Quantity) from sales
--better way 
select Pid as 'Pid' , sum(Quantity) from sales group by rollup(Pid) 
--perform sum() on the result of query 
select Pid,SalesMan,sum(Quantity)as 'Quantities' from sales 
group by Pid,SalesMan
--output 1,ahmed  2,ahmed   3,ahmed 4,ahmed 
--then   1,ali  2,ali   3,ali  
--it seems like sorting by salesman then applaying cartisian product 
select Pid,SalesMan,sum(Quantity)as 'Quantities' from sales 
group by rollup(Pid,SalesMan)
--sort by pid
--outpu 1,ahmed 1,ali 1,aya... 
--then total sum for pid=1 
select Pid,SalesMan,sum(Quantity)as 'Quantities' from sales 
group by rollup(SalesMan,pid)
--see the diffrence between last 3 queries 
select Pid,SalesMan,sum(Quantity)as 'Quantities' from sales 
group by cube(SalesMan,pid)
--display sum for every pid with every salesman 1,ahmed 1,ali ....
--display total sum for every pid 
--display total sum for every salesman 
--do all work of the last 3 queries 
select Pid,SalesMan,sum(Quantity)as 'Quantities' from sales 
group by grouping sets(SalesMan,pid)
--removing the result of group by 
--display total sum for each pid 
--then total sum for each salesman 
------------------------------------------------
--------------PivotColumns----------------------
--if you need to display the result of last query 
--in a 2 d matrix like this in p47/photos 
--pivot means group by with rotation for the table 
--transform rows into columns 
select * from sales 
pivot (sum(Quantity)for SalesMan in([ahmed],[ali],[aya],[omnia]))
as PVT
-------------------------------------------------
--------------UnPivotColumns---------------------
--used to transform columns into rows
--if we have data in p48/photos 
--with unpivot it converted to p49/photos 
create table sales1
(
 Pid int,
 JanS int,
 FebS int,
 MarS int
)
select Pid,Month,Sales from
(select * from sales1 )p
unpivot (Sales for Month in ([JanS],[FebS],[MarS]))as UPVT



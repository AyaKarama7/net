use MyDB

--physical table 
create table exam(id int primary key,edate date,numofQ int)
--stored in DB 
--you can use it in many sessions"queries" as using DB
--the only way to remove this table is to drop it 
drop table exam 

--logical table "session based table"
create table #exam(id int primary key,edate date,numofQ int)
--stored in temprary tables in tempdb 
--you can use only in the session you created in 
--remove after closing the seesion 
--you can create many tables of the same name using one data base 
--all of them stored in temporary tables 
--but differs in id
--see LogicalTableN/Queries 

--global table "shared table" 
create table ##exam(id int primary key,edate date,numofQ int)
--stored in temprary tables in tempdb 
--removed after closing the session created in  
--shred between many sessions
--see GlobalTableN/Queries 

--table variable 
declare @t table (x int)
--local in batch 


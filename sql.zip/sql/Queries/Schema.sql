use MyDB
create schema aya
alter schema aya transfer Employee  --move to schema='aya'
select * into Employee from aya.Employee
select * into aya.Department from Department
select User_Name()
--create shortcut 
create synonym AE for aya.Employee
select * from AE 
--the same as 
select * from aya.Employee

use MyDB
create table #exam(id int primary key,edate date,numofQ int)
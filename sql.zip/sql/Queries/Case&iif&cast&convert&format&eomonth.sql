use MyDB
select Fname,Salary ,
case 
when Salary <3000 then 'low'
when Salary =3000 then 'mid'
else 'high'
end as newSalary
from Employee

select Fname,Salary, iif(Salary>=3000,'high','low')from Employee
--if you have only 1 condition(1 if,else)

update Employee set Salary =
case 
when Salary <3000 then Salary+100
when Salary =3000 then Salary+200
else Salary+300
end 
---------------------------------------------
select cast(getdate()as varchar(20))
select convert(varchar(20),getdate())
select convert(varchar(20),getdate(),102)
select convert(varchar(20),getdate(),103)
select convert(varchar(20),getdate(),104)
select convert(varchar(20),getdate(),105)
select format(getdate(),'dd-mm-yy')
select format(getdate(),'ddd mmm yyy')
select format(getdate(),'ddd-mmm-yyy')
select format(getdate(),'dddd/mmmm/yyyy')
select format(getdate(),'hh:mm:ss')
select format(getdate(),'mmmm')
select format(getdate(),'yyyy')
select format(getdate(),'ddd/mmm/yyy  hh:mm:ss')
select EOMONTH(getdate())
select format(EOMONTH(getdate()),'dddd')
select format(EOMONTH('7-3-2003'),'dddd')
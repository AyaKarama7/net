use MyDB
select top(1) Fname from Employee order by len(Fname)
--create my own function
--Scalar
create function getsname(@id int)returns varchar(20)--declration
  begin --defintion
  declare @name varchar(20) 
  select @name=(select Fname from Employee where SSN=@id)
  return @name
  end
--call the function
select getsname(1) 
--error
--as the compiler think the function is a scalar one
--so it search for it in scalar built in functions 
--and don't find it 
--solution:
select dbo.getsname(1) 
--inline 
create function getEmployee(@did int)returns table 
as return 
(select Fname,Salary*12 as TotalSalary from Employee where Dnum=@did)

select * from getEmployee(10)
--multistatement 
create function getEmployees(@id varchar(20))
returns @t table(id int,name varchar(20))
as 
begin
if @id='first'
insert into @t select SSN,Fname from Employee
else if @id='last'
insert into @t select SSN,Lname from Employee
else 
insert into @t select SSN,Fname+' '+Lname from Employee
return
end

select * from getEmployees('full')
-------------------------------------------------
--Built in windowing functions
--lead lag first_value last_value 
select Fname,Salary ,
 x=lead(Fname)over(order by Salary), --after 
 y=lag(Salary)over(order by Salary)  --before 
from Employee

select * from
(
 select Fname,Salary ,
 x=lead(Fname)over(order by Salary), --after 
 y=lag(Salary)over(order by Salary)  --before 
 from Employee
)as NewTable where Fname='nahla'

select Fname,Salary ,Dnum,
 x=lead(Fname)over(partition by Dnum order by Salary), --after 
 y=lag(Salary)over(partition by Dnum order by Salary)  --before 
from Employee

select Fname,Salary ,
 x=first_value(Fname)over(order by Salary), --first row in query
 y=last_value(Fname)over(order by Salary)   --last row in query
from Employee
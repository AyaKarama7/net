use MyDB
create table dept
(
   did int primary key,
   dname nvarchar(50),
)
create table emp
(
   eid int identity(1,1),--start =1 incremented by 1
   ename nvarchar(50) not null,
   eadd nvarchar(50) default 'cairo',
   hire_date date default getdate(),
   sal int,
   overtime int,
   netsal as (isnull(sal,0)+isnull(overtime,0)) persisted,
   BD date,
   age as (Year(getdate())-Year(hire_date)),
   --age can't be persisted 
   --as getdate() is a determenstic function
   --change at evrey calculation
   gender char,
   hour_rate int not null,
   did int,
   constraint c1 primary key(eid,ename), --composite pk
   constraint c2 unique(sal),
   --the same as  sal int unique
   constraint c3 unique(sal,overtime),
   --means both together are unique
   --1000,5 =unique
   --1000,10=unique 
   --composite unique
   constraint c4 check(sal>1000),
   constraint c5 check(eadd in ('cairo','alex','minia')),
   --default value must be in check 
   constraint c6 check(gender in ('f','m')),
   constraint c7 foreign key(did) references dept(did)
   on delete set null on update cascade 
)
--create constraints after creating table 
alter table emp add constraint c8 check(hour_rate>100)
--Error, hour rate current data in the table 
--conflict with the condition
alter table emp drop c3 --remove constraint 
------------------Rule----------------------
--constraint--->new data 
--constraint--->shared between more than 1 table
--new datatype->constraint + default value
--created on the level of schema 
create rule r1 as @x>1000
sp_bindrule r1 , 'Employee.Salary' 
sp_bindrule r1 , 'emp.overtime' 
--activate rule on Employee.Salary
--if you tried to enter Salary <=1000 failure occur
sp_unbindrule 'Employee.Salary'
--you should unbindrule before drroping it 
sp_unbindrule 'emp.overtime'
drop rule r1
------------default--------------
create default d1 as 5000
sp_bindefault d1, 'Employee.Salary' 
--any cell where you enter null for salary take value =5000
sp_unbindefault  'Employee.Salary' 
drop default d1
------------create datatype------------
--create datatype called complexDT (int>1000,default=5000)
create rule r as @x>1000
create default d as 5000
sp_addtype complexDT,int 
sp_bindrule r,complexDT
sp_bindefault d,complexDT
create table test3
(
  id int ,
  name varchar(30),
  salary complexDT,
)
--datatype take only one rule 
--if you give it more than 1 rule it overwrites them 
--Diffrence between constraint and rule 
--Constraint:
--on the level of table
--the column can take many constraints
--should be appropriate for old data
--can't be linked with datatype
--Rule:
--on the level of schema
--the column can take only one constraint
--on the new data
--can be linked with datatype
--replace check constraint



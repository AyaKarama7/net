use MyDB
create nonclustered index myindex on Employee(Fname)
create nonclustered index myindex1 on Employee(Lname)
select * from Employee where Fname='ahmed'
create table myIndex
(
   id int primary key,  -- custered
   name varchar(20),
   mail varchar(50) unique --non clustered
)
create unique index i1 on Employee(Gender)
--Error 
--unique is a constraint 
--the constraint shoud be appropriate with the old data 
create unique index i2 on myIndex(name)

select * from Employee where Salary>1000
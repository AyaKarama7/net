Use MyDB
select * into Employee1 from Employee
select * into Employee2 from Employee
select * into Employee3 from Employee
drop table Employee1    
--delete structure + Date 
--no more existance for the table
delete from Employee2
--delete data 
--structure still exist
--can take where so you can use it to remove part of the table
--more slower than truncate 
--as it is written in log file so you can rollback (������ �������)
--don't reset the identity
truncate table Employee3
--delete data 
--structure still exist
--can't take where so you can't use it to remove part of the table
--more faster than delete
--reset identity 
--as it isn't always written in log file so you can't rollback
create table test (id int identity,name nvarchar(20))
insert into test values('ali')
create table test1 (id int identity,name nvarchar(20))
insert into test1 values('ali')
delete from test 
truncate table test1
insert into test values('aya')
insert into test1 values('aya')
select * from test --don't reset identity
select * from test1 --reset identity
--you should use delete with any parent has a child 
--you can't use truncate with any parent has a child 

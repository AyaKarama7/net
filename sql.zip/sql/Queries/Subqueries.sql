use MyDB
alter table Employee add Age int
select * from Employee where Age<(select avg(Age) from Employee)
--inner select then outer select
--output data of any student their age<avg age of all students
select *,(select count(SSN) from  Employee) from Employee
--output students data then column contain total num of students
select distinct Dname from Department where Dnum in(select Dnum 
from Employee where Dnum is not null)
--output depart name of any department its num exist in Employee
--output names of departments contain Emplyees
select distinct Dname from Employee E inner join Department D on D.Dnum=E.Dnum
--The same as previous query
--join is more faster subqueries
--use subqueries only when there is no other chois as it is slow
--before implementing subquery the engine see if it can translate it to 
--another equal query like join to safe time 

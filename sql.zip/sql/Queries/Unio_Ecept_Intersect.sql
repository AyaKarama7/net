use MyDB
--Run to see the diffrence between statements
--Statement 1
select Fname from Employee
select Dname from Department
--Statement 2
select Fname from Employee
union all
select Dname from Department
--the output colum take the name from the first select "Fname"
--Statement 3 (sort+distinct)
select Fname from Employee  
union 
select Dname from Department
--Statement 4 (sort+distinct)
select Fname from Employee
intersect
select Lname from Employee
--Statement 5 (sort+distinct)
select Fname from Employee
except
select Lname from Employee
--num of columns selected in the first half of the statement 
--should be equal to the num of them in the second half
--Statement 6 (Error)
select Fname,Lname from Employee
union all
select Dname from Department
--Statement 7
select Fname from Employee
except
select Lname from Employee
union 
select Dname from Department

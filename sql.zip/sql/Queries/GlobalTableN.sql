create table ##exam(id int primary key,edate date,numofQ int)
--error exist table 
select * from ##exam

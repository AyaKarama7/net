use MyDB
alter table Employee add Address varchar
alter table Employee add city varchar(20)
create view valex as select * from Employee where city='alex'
--hide metadata from user
select * from valex
--hide names of metadata
create view vcairo(id,name) as select SSN,Fname
from Employee where city='cairo'
select id,name from vcairo

create view vall as 
select * from vcairo 
union all 
select SSN,Fname from valex

create view vjoin(Eid,Ename,Did,Dname)as
select SSN,Fname,D.Dnum,Dname from 
Employee E inner join Department D
on D.Dnum=E.Dnum

select * from vjoin

alter view vjoin(Eid,Ename,Did,Dname,city)as
select SSN,Fname,D.Dnum,Dname,city from 
Employee E inner join Department D
on D.Dnum=E.Dnum
select * from vjoin

create view vproject as 
select Ename,Did,Pname from 
vjoin inner join Project
on Did=Dnum
select * from vproject

sp_helptext 'vjoin'
--display the code created vjoin 
--where is security ??!
--solution:
alter view vjoin(Eid,Ename,Did,Dname,city)
with encryption 
as
select SSN,Fname,D.Dnum,Dname,city from 
Employee E inner join Department D
on D.Dnum=E.Dnum
--the code is encrypted
sp_helptext 'vjoin'
--also you can't script encrypted views 
--no one including adminstrator can access encrypted code
--------------------------------------------------------------
----DML with view 
--you an' write DML queries inside view body 
--but you can do them on view for example you 
--can insert values into view but there are 
--some conditions 
--view one table "vcairo"
drop index i1 on Employee
insert into vcairo values(150,'karima')
select * from vcairo
select SSN from Employee
--values inserted to actual table 
--there are sum columns not inserted like Lname...
--these column should allow 1 of 4 for insert query to work 
--identity/allow null/default value/driven 
--can update only columns in view 

--view multi tables "vjoin"
--can't delete 
--can insert or update but the query should affect only one table 
insert into vjoin values(55,'moataz',10,'cs','cairo')
--not updatable because the modification affects multiple base tables
insert into vjoin(Eid,Ename) values(55,'moataz')
--updatable as affecting 1 row 

---------------Indexed view-------------------------
--do physical copy for data 
create view vdata 
with schemabinding 
as 
select SSN,Fname from dbo.Employee
---------------NOTE 
insert into valex(SSN,Fname,city) values(24,'alexa','cairo')
--here it insert into the actual table 
--no updates affect the view 
--what if you need to insert only data can affect the group
alter view valex 
as select * from Employee where city='alex'
with check option

insert into valex(SSN,Fname,city) values(24,'alexa','cairo')--failed







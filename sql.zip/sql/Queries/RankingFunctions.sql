use MyDB
select * , Rank() over(partition by Gender order by Salary)as RA
from Employee
--devide table to n partitions(Ex:m,f)
--order data in partition m ascending by salary
--then do the same with partition f
select * , Rank() over(partition by Gender order by Age)as RA
from Employee
--repeated values in one partition take the same number in RA column
select * from
(select * , Rank() over(partition by Gender order by Age)as RA
from Employee)as NT where RA=1
--subquery 
--min Age at each partition

select * from 
(select *,ROW_NUMBER()over(order by Age)as RA from Employee)as NT
where RA=5;

select * from 
(select *,Dense_rank()over(order by Age)as DR from Employee)as NT
where DR=5;

select * from 
(select *,ROW_NUMBER()over(Partition by Gender 
order by Age)as RA from Employee)as NT
where RA=3;

select * from 
(select *,Dense_rank()over(Partition by Gender 
order by Age)as DR from Employee)as NT
--where DR=3;

select * ,NTILE(5)over(order by Age)as NR from Employee

--Diffrence between Rank and denses_rank
--when you have repeated vallues like this:
--Age    DR     Rank
--1       1      1
--2       2      2
--3       3      3
--3       3      3
--4       4      5 
﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace D03
{
    class Class1
    {
        //public static void FunTwo()
        //{
        //    //Console.WriteLine("Fun Two");

        //    //int X = 0;
        //    //int Y = 7 / X;

        //    StackTrace sTrace = new StackTrace();

        //    StackFrame[] sFrames = sTrace.GetFrames();

        //    for ( int i=0; i < sFrames?.Length; i++)
        //        Console.WriteLine(sFrames[i].GetMethod().Name);
        //}

        //public static void FunOne ()
        //{
        //    FunTwo();
        //}

        public static void PrintLine (int N=5 , string Pattern="#")
        {
            //FunOne();
            int i = 0; 
            for (; i< N; i++)
                Console.Write(Pattern);
            Console.WriteLine("");
        }

        ///Value Types , pass By Value
        //public static void SWAP (int X , int Y)
        //{
        //    int Temp = X;
        //    X =Y;
        //    Y = Temp;
        //}

        ///Value Type , Pass By Reference
        public static void SWAP(ref int X,ref int Y)
        {
            int Temp = X;
            X = Y;
            Y = Temp;
        }

        ///Reference Type , Pass By Value
        public static int SumArray(int[] Arr)
        {
            int Sum = 0;
          
            for (int i = 0; i < Arr?.Length; i++)
                Sum += Arr[i];
            Console.WriteLine(Arr.GetHashCode());
            return Sum;
        }

        ///By Value : Read Only
        ///By Reference : Read & Write 
        ///By out : Write first 
        public static void SumMul(int X , int Y , out int S , out int M)
        {
            S = X + Y;
            M = X * Y;
        }


        static void MainV2 ()
        {
            #region out
            //int A = 7, B = 3;//, SResult, MResult;

            ////SumMul(A, B, out SResult, out MResult);

            //SumMul(A, B, out int SResult, out int MResult);

            //Console.WriteLine($"Sum = {SResult}");
            //Console.WriteLine($"Mul = {MResult}");

            //SumMul(10, 7, out _, out int SR);
            //Console.WriteLine(SR); 
            #endregion

            #region Refrence Types
            //int[] MyA = { 1, 2, 3, 4, 5 };

            //Console.WriteLine(MyA.GetHashCode());

            //Console.WriteLine(SumArray(MyA)); 
            #endregion

            #region Value Types
            //int A = 7, B = 3;

            ////SWAP(A, B); /// Pass By Value
            //SWAP(ref A, ref B); /// Pass By Reference

            //Console.WriteLine($"A = {A}");
            //Console.WriteLine($"B = {B}"); 
            #endregion

            #region Named & Default input Paramters
            //int X;
            //Console.WriteLine("Enter New Value : ");
            //PrintLine(7 , "-_-");

            //X = int.Parse(Console.ReadLine());
            //Console.WriteLine(++X);
            //PrintLine(5 , "#");
            //PrintLine();
            //PrintLine(7);

            ////PrintLine( , "="); ///Not Valid
            /////Named Input Paramters

            //PrintLine(Pattern:@"/**\" , N:4);
            //PrintLine(Pattern: "=");


            //++X; 
            #endregion

            //String Str = @"C:\MyFolder\SubFolder";

        }
    }
}

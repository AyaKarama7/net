﻿using System;
using System.Collections.Generic;
using System.Text;
using Common;


namespace D03
{
    enum Grades
    {
        A , B , C , D , F
    }

    class Class2
    {
        static void Main ()
        {

            Grades MyG = Grades.C;

            MyG = Grades.F;

            if (MyG == Grades.F) Console.WriteLine(":(");


            switch (MyG)
            {
                case Grades.A:
                    break;
                case Grades.B:
                    break;
                case Grades.C:
                    break;
                case Grades.D:
                    break;
                case Grades.F:
                    break;
                default:
                    break;
            }


            //TypeA A;

            //Point P1;
            /////Allocation 8 UnInitialized bytes in Stack 

            //Console.WriteLine(P1);

            Point P2 = new Point(10, 15);
            ///P2 allocated in Stack
            ///use new keyword just for Ctor selection
            
            Console.WriteLine(P2);

            Point P3 = new Point(15);
            Console.WriteLine(P3);

            Point P1 = new Point();
            Console.WriteLine(P1);

            int X = new int();
            Console.WriteLine(X);


        }
    }
}

﻿using System;

namespace D03
{
    //struct Temp
    //{

    //}
    class Program
    {
        static void MainV1(string[] args)
        {
            #region Casting Built in Value Types

            //int X = 50;
            //long Y = 5000;


            ////Y = X;
            /////Implicit Casting 
            /////Int64 = Int32
            /////Safe Casting , No RunTime Errors 

            //Y = long.MaxValue;

            //X =(int) Y;
            /////Int32 = Int64 
            /////UnSafe Casting 
            /////Explicit Casting
            /////Default behavior for CLR , Will not Throw OverflowException when overflow happens


            /////CLR will throw OverFlowException 
            //checked
            //{
            //    X = (int)Y;
            //}



            //Console.WriteLine($"X = {X}");
            //Console.WriteLine($"Y = {Y}");



            #endregion

            #region Boxing , UnBoxing
            ///System.Object & Any ValueType

            //int X = 5;

            //object O1 = new object();

            //O1 = X;
            /////Base Ref = Child
            /////Safe
            /////Boxing

            //O1 = "Hello";

            //int Y;

            //Y = (int)O1;
            ////Derived = Base
            /////unSafe , Explicit
            /////UnBoxing

            //Console.WriteLine(Y); 
            #endregion

            #region Nullable Types
            //int X = 50;
            ////X = null;

            //int? Y; ///Nullable int , IL : Nullable<int>

            //Y = 5000;
            //Y = null;

            ////Y = X;
            /////Safe Casting , Implicit


            ////X = (int)Y;
            /////UnSafe , Explicit


            /////Protective Programming
            ////if (Y != null)
            ////    X = (int)Y;
            ////else
            ////    X = 0;

            ////if (Y.HasValue)
            ////    X = Y.Value;
            ////else
            ////    X = 0;

            ////X = Y.HasValue ? Y.Value : 0;

            //X = Y ?? 0;


            //Console.WriteLine($"X = {X}");
            //Console.WriteLine($"Y = {Y}"); 
            #endregion

            #region Null Operators
            //double D = default;

            //int[] Arr = default;

            ////for (int i = 0; (Arr != null) && (i < Arr.Length); i++)
            ////    Console.WriteLine(Arr[i]);

            /////Null Propagation Operator \ Null Conditional Operator
            //for (int i = 0; i < Arr?.Length; i++)
            //    Console.WriteLine(Arr[i]);

            //Employee E = default;

            ////Console.WriteLine(E.Dept.Name); ///Unsafe

            //Console.WriteLine(E?.Dept?.Name??"NA");


            //int R = Arr.Length; ///UnSafe
            //int? RR =  Arr?.Length; ///Safe Arr?.Lenght ====> (Arr != null)? Arr.lenght: null
            //int RRR = Arr?.Length?? 0; //Safe 
            #endregion

            #region Implicit Typed Local Variable

            ////double D = 15.3;

            ////Console.WriteLine(D.GetType().Name);

            ////D = "Hello";

            //var D = 15.3;
            /////Compiler will Detect Variable Data type
            /////Based on Initial Value
            /////Implicit Typed Local Variable
            /////Can't be not Initialized
            /////Can't be initialized with null

            //Console.WriteLine(D.GetType().Name);

            ////D = "Hello";

            #endregion

        }
    }

    class Dept 
    {
        public string Name;
    }
    class Employee
    {
        public Dept Dept;
    }

}

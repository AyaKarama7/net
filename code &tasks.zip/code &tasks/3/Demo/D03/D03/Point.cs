﻿using System;
using System.Collections.Generic;
using System.Text;

namespace D03
{
    struct Point
    {
        int X;
        int Y;

        ///User Defined Ctor
        public Point(int _X , int _Y)
        {
            ///Any userdefined Ctor in Struct
            ///Ctor must fully initialize all Struct Attributes
            X = _X;
            Y = _Y;
        }
        public Point(int N)
        {
            X = Y = N;
        }

        ///Compiler will always Generate Paramterless Ctor
        ///to initialize all Members with default value 
        ///Struct can't have userdefined paramterless ctor
        //public Point()
        //{
        //    X = Y = 0;
        //}

        public override string ToString()
        {
            return $"({X},{Y})";
        }



    }
}

﻿using System;

namespace Common
{
    ///Default Access Modifier inside Namespace : internal 
    ///Internal vs Public
   public struct TypeA
    {
        int X;
        ///Default access Level : Private

        internal int Y;
        ///Accessable inside assembly file , inside the same Project

        public int Z; 

        public void Print ()
        {
            Console.WriteLine($"{X} {Y} {Z}");
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common
{
    class TypeB
    {
        public TypeB()
        {
            TypeA AVar;

            AVar.Y = AVar.Z = 2;

        }
    }
}

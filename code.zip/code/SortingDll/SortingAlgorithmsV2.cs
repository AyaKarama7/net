﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortingDll
{
    public delegate TResult CompFunDelDT<in T1, in T2, out TResult>(T1 x, T2 y);
    //any fun take any 2 inputs and return any output

    public class SortingAlgorithmsV2
    {
        public static void BSort(int[] items)
        {
            for (int i = 0; i < items?.Length; i++)
                for (int j = 0; j < items.Length - i - 1; j++)
                    if (CompFunctions.CompGrt(items[j], items[j + 1]))
                        SWAP(ref items[j], ref items[j + 1]);
        }
        public static void BSortV2<T>(T[] items,CompFunDelDT<T,T,bool>FPtr)
        {
            for (int i = 0; i < items?.Length; i++)
                for (int j = 0; j < items.Length - i - 1; j++)
                    if (FPtr?.Invoke(items[j], items[j + 1]) == true) 
                        SWAP(ref items[j], ref items[j + 1]);
        }
        public static void BSortV3<T>(T[] items, Func<T, T, bool> FPtr)
        {
            for (int i = 0; i < items?.Length; i++)
                for (int j = 0; j < items.Length - i - 1; j++)
                    if (FPtr?.Invoke(items[j], items[j + 1]) == true)
                        SWAP(ref items[j], ref items[j + 1]);
        }
        public static void SWAP<T>(ref T X, ref T Y)
        {
            T Temp = X;
            X = Y;
            Y = Temp;
        }
    }
    public class CompFunctions
    {
        public static bool CompGrt(int L, int R) { return L > R; }
        public static bool CompLes(int L, int R) { return L < R; }

    }
    public class CompFunctionsV02
    {
        public static bool CompAbsGrt(int L, int R) { return Math.Abs(L) > Math.Abs(R); }
        public static bool CompString(string s,string T) { return s.Length > T.Length; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortingDll
{
    ////step 0:Delegate datatype declration
    //public delegate bool CompFunDelDT(int L, int R);
    ////word delegate lead to the creation of a new class in the base class library 
    ////can access any function take (int,int) and return bool
    ////whether this function is static or objrct regardless its name and access modifier
    //public class SortingAlgorithms
    //{
    //    public static void BSort(int[] items)
    //    {
    //        for (int i = 0; i < items?.Length; i++)
    //            for (int j = 0; j < items.Length - i - 1; j++)
    //                if (CompFunctions.CompGrt(items[j], items[j + 1]))
    //                    SWAP(ref items[j], ref items[j + 1]);
    //    }
    //    public static void BSortV2(int[] items,CompFunDelDT FPtr)
    //    {
    //        for (int i = 0; i < items?.Length; i++)
    //            for (int j = 0; j < items.Length - i - 1; j++)
    //                if (FPtr?.Invoke(items[j], items[j + 1])==true)//handle nullable exception 
    //                    SWAP(ref items[j], ref items[j + 1]);
    //    }
    //    public static void SWAP(ref int X, ref int Y)
    //    {
    //        int Temp = X;
    //        X = Y;
    //        Y = Temp;
    //    }
    //}
    //public class CompFunctions
    //{
    //    public static bool CompGrt(int L, int R) { return L > R; }
    //    public static bool CompLes(int L, int R) { return L < R; }

    //}
    //public class CompFunctionsV02
    //{
    //    public static bool CompAbsGrt(int L,int R) { return Math.Abs(L) > Math.Abs(R); }
    //}
}

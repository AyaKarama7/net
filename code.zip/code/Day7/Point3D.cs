﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7
{
    internal class Point3D
    {
        public int X { get => X; set => X = value; }//set&get property with lambada expression
        public Point3D() => Console.WriteLine("Ctor"); //get ctor with lambada expression
        public Point3D(int a) => X = a;//set ctor with lambada expression
        public override string ToString() => $"{X}";//fun with lambada expression
        

    }
}

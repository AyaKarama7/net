﻿using System.Collections;
using SortingDll;
using System.Linq;
namespace Day7
{
    internal class Program
    {
        public static int SumArray(ArrayList a)
        {
            int sum = 0;
            for (int i = 0; i < a?.Count; i++)
                sum += (int)a[i];//explicit unsafe casting +unboxing
            return sum;
        }
        public static int SumList(List<int> L)
        {
            int sum = 0;
            for (int i = 0; i < L?.Count; i++) sum += L[i];//implicit safe casting without unboxing
            return sum;
        }

        public delegate int StringFunctionsDelDT(string s);
        public delegate bool CheckDelDT(int x);//non generic
        public delegate bool CheckDelDT<in T>(T x);//generic,only for input
        public static List<int> FindList(List<int> L,CheckDelDT p)
        {
            List<int> NList = new List<int>();
            for (int i = 0; i < L?.Count; i++)
            {
                if (p?.Invoke(L[i]) == true) NList.Add(L[i]);
            }
            return NList;
        }
        public static List<T> FindListG<T>(List<T> L, CheckDelDT <T>p)
        {
            List<T> NList = new List<T>();
            for (int i = 0; i < L?.Count; i++)
            {
                if (p?.Invoke(L[i]) == true) NList.Add(L[i]);
            }
            return NList;
        }
        public static List<int>FindOdd(List<int>L)
        {
            List<int> odd=new List<int>();
            for(int i=0;i<L?.Count;i++)
            {
                if (L[i] % 2 == 1) odd.Add(i);
            }
            return odd;
        }
        static void Main(string[] args)
        {
            #region Disadvantages of using non-generic/system object collections
            //ArrayList alist = new ArrayList();
            //alist.Add(1);//boxing
            //alist.Add(3);
            //alist.Add(3);
            //alist.Add(2);
            //alist.Add("8");//complier can't check type safety,all is object
            //alist.AddRange(new int[] { 4, 5, 6, 7 });
            //alist.Remove(3);//remove the first element = 3
            //for (int i = 0; i < alist?.Count; i++) Console.Write($"{alist[i]} ");
            //Console.WriteLine();
            ////Console.WriteLine(Sum(alist));unhandled exception as alist contain string = "8" 
            #endregion

            #region List
            //List<int> L = new List<int>();//more readable
            //L.Add(9);
            //L.Add(2);
            ////L.Add("3");Compiler check & enforce Type safety during compilation
            //Console.WriteLine($"ListSum={SumList(L)}");
            //Console.WriteLine($"ListCount={L.Count}");//2-->As you add 2 elements 
            //Console.WriteLine($"ListCapacity={L.Capacity}");
            ////4->As the compiler increase the capacity of list to Capcity*2
            ////At first if Capcity =0 after adding first element it become 4
            ////then you add until reach capacit--> size=4 capacity=4
            //L.AddRange(new int[] { 3, 4 });
            //Console.WriteLine($"ListCount={L.Count}");
            //Console.WriteLine($"ListCapacity={L.Capacity}");
            ////After that if you add -->size=5 capacity=8-->(4*2)
            //L.Add(5);
            //Console.WriteLine($"ListCount={L.Count}");
            //Console.WriteLine($"ListCapacity={L.Capacity}");
            ////the time here is consumed by overhead but it isn't to big as every time i add i multiply by 2
            ////you can access only element in the range of size not capacity
            ////size=5,capacity=8 , L[4]-->valid , List[6]-->not valid
            ////you can remove capacity you don't need
            //L.TrimExcess();
            //Console.WriteLine($"ListCount={L.Count}");
            //Console.WriteLine($"ListCapacity={L.Capacity}");
            //L.Add(6);
            //Console.WriteLine($"ListCount={L.Count}");
            //Console.WriteLine($"ListCapacity={L.Capacity}");
            //L.RemoveAt(0);//size=size-1,capacity=capacity,work by shefting,remove element at index 1
            //for (int i = 0; i < L?.Count; i++) Console.Write($"{L[i]} ");
            //Console.WriteLine("");
            #endregion

            #region Dictionary
            //Dictionary<string, long> PhoneBook = new Dictionary<string, long>();//<key,value>
            //PhoneBook.Add("ABC", 123);
            //PhoneBook.Add("XYZ", 456);
            //PhoneBook.Add("PWV", 789);

            ////PhoneBook.Add("XYZ", 342);unhandled exception , dublicated key
            ////solution 1:Update by indexer
            //PhoneBook["XYZ"] = 342;
            ////solution 2:handle exception
            //if (!PhoneBook.TryAdd("XYZ", 342)) PhoneBook["XYZ"] = 342;
            //if (PhoneBook.ContainsKey("XYZ")) PhoneBook["XYZ"] = 342;
            //PhoneBook["DEF"] = 777;//Add

            //Console.WriteLine($"{PhoneBook["XYZ"]}");//get
            ////Console.WriteLine($"{PhoneBook["abc"]}");unhandled exception,not found key
            ////Solution:handle exception
            //if (PhoneBook.ContainsKey("abc")) Console.WriteLine($"{PhoneBook["abc"]}");
            //else Console.WriteLine("NF");
            //if (PhoneBook.TryGetValue("abc", out long v)) Console.WriteLine(v);
            //else Console.WriteLine("NF");

            //foreach (KeyValuePair<string, long> p in PhoneBook)
            //    Console.WriteLine($"{p.Key}::{p.Value}");
            #endregion

            #region SingleDelegateEx01
            ////step0:declare pointer to function
            //StringFunctionsDelDT ptr;
            ////step1:intialize pointer 
            //ptr = new StringFunctionsDelDT(StringFunctions.GetLenght);
            ////step2:Access data using ptr
            //int R = ptr.Invoke("ABC");
            //Console.WriteLine(R);

            ////ptr points to another fun
            //ptr = new StringFunctionsDelDT(StringFunctions.GetUpChar);
            //R = ptr.Invoke("XaYb");
            //Console.WriteLine(R);

            ////ptr = new StringFunctionsDelDT(StringFunctions.GetFullName);compiler enforce signature

            ////ptr to object fun
            //StringFunctions obj = new StringFunctions() { Ch = 'z' };
            //ptr = new StringFunctionsDelDT(obj.GetCharNum);
            //R = ptr("zxzbzczz");//R=ptr.Invoke("zxzbzczz");
            //Console.WriteLine(R); 
            #endregion

            #region Example02
            //int[] arr = { 5, 6, 4, -2, 3, 1, -8, 7 };

            //SortingAlgorithms.BSort(arr);
            //foreach (var i in arr) Console.Write($"{i} ");
            //Console.WriteLine();

            //CompFunDelDT FPtr = new CompFunDelDT(CompFunctions.CompLes);
            ////Previous line can be written like this:
            //CompFunDelDT Fptr1 = CompFunctions.CompLes;//implicit casting from CompLes to FPtr
            //SortingAlgorithms.BSortV2(arr, FPtr);
            //foreach (var i in arr) Console.Write($"{i} ");
            //Console.WriteLine();

            //FPtr = CompFunctionsV02.CompAbsGrt;
            //SortingAlgorithms.BSortV2(arr, FPtr);
            ////simple way to write las previous 2 lines
            //SortingAlgorithms.BSortV2(arr, CompFunctionsV02.CompAbsGrt);
            //foreach (var i in arr) Console.Write($"{i} ");
            //Console.WriteLine(); 
            #endregion

            #region Example03
            //List<int> iList = Enumerable.Range(0, 100).ToList();//generate rang from 0 to 100 and put them in iList
            //List<int> oList = FindOdd(iList);
            //for (int i = 0; i < oList?.Count; i++) Console.Write($"{oList[i]} ");
            //Console.WriteLine();

            ////what if I need even numbers ,numbers devided by 5 , and numbers devided by 7...???
            //CheckDelDT ptr = ConditFunctions.ChkDB5;
            //oList = FindList(iList, ptr);
            //for (int i = 0; i < oList?.Count; i++) Console.Write($"{oList[i]} ");
            //Console.WriteLine();

            ////What if I have a list of strings and need to return list of strings with length<4???
            ////try generics
            //List<string> SList = new List<string> { "Aya", "Ahmed", "Karamah", "Ali", "Omnia" };
            //CheckDelDT<string> p = ConditFunctions.ChkSiz;
            //List<string> L = FindListG(SList, p);
            //for (int i = 0; i < L?.Count; i++) Console.Write($"{L[i]} ");
            //Console.WriteLine();

            ////Sort List of strings from smallest length to biggest
            //CompFunDelDT<string, string, bool> PS = CompFunctionsV02.CompString;
            //var Arr = SList.ToArray();
            //SortingAlgorithmsV2.BSortV2(Arr, PS);
            //foreach (var i in Arr) Console.Write($"{i} ");
            //Console.WriteLine();

            ////Built in delegate:
            //Predicate<int> PR = ConditFunctions.ChkOdd;//take t and return bool
            //Console.WriteLine(PR(8));
            //Func<string, string,bool> PF = CompFunctionsV02.CompString;
            //SortingAlgorithmsV2.BSortV3(Arr, PF);
            //foreach (var i in Arr) Console.Write($"{i} ");
            //Console.WriteLine();
            #endregion

            #region AnonymousMethod
            Predicate<int> P = delegate (int x) { return x % 13 == 0; };//anonymous method
            Console.WriteLine(P(26));
            #endregion

            #region LambadaExpression
            Predicate<int> P1 = (int x) => { return x % 13 == 0; };//equals above lines

            Predicate<int> P2 = x => x % 13 == 0;//equals above lines,compiler already know that x is int and fun return bool

            List<int> L = Enumerable.Range(0, 100).ToList();
            List<int> NL = FindListG<int>(L, x => x > 90);
            foreach (var i in NL) Console.Write($"{i} ");
            Console.WriteLine();

            //you can remove return if the fun only return single line of code

            int n = 8;
            P2 = x => x % n == 0;

            //Action : built in delegate return void
            Action Aptr = () => Console.WriteLine("Hello World!");
            Aptr?.Invoke();
            //see Point3D class
            #endregion

        }
        class StringFunctions
        {
            public static int GetLenght(string Str) { return Str?.Length ?? -1; }
            //(string)return int;
            public char Ch { get; set; }
            internal int GetCharNum(String Str)
            {
                int Coutner = 0;
                for (int i = 0; i < Str?.Length; i++)
                    if (Str[i] == this.Ch) Coutner++;
                return Coutner;
            }
            //(string)return int;
            public static int GetFullName(string FName, string LName) { return FName.Length + LName.Length; }
            //(string,string)return int;
            public static int GetUpChar(string Str)
            {
                int Coutner = 0;
                for (int i = 0; i < Str?.Length; i++)
                    if (Char.IsUpper(Str[i])) Coutner++;
                return Coutner;
            }
            //(string)return int;
        }
        class ConditFunctions
        {
            public static bool ChkOdd(int x) { return x % 2 == 1; }
            public static bool ChkEve(int x) { return x % 2 == 0; }
            public static bool ChkDB5(int x) { return x % 5 == 0; }
            public static bool ChkSiz(string s) { return s?.Length < 4; }
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D06
{
    abstract class GeoShape
    {
        public int Dim1 { get; set; }
        public int Dim2 { get; set; }
        public GeoShape(int dim1,int dim2)//used to intialize members of the abstract class inside child class
        {
            Dim1 = dim1;
            Dim2 = dim2;
        }
        public abstract double Area();
        public abstract double Perimter { get; }
        public void fun() { Console.WriteLine("Concrete fun has bodey,not abstract"); }
    }
    class Rect:GeoShape
    {
        public Rect(int w,int h) : base(w, h) { }
        public override double Area()
        {
            return Dim1 * Dim2;
        }
        public override double Perimter { get { return (Dim1 + Dim2)*2; } }

    }
    abstract class BaseSquare : GeoShape
    {
        public BaseSquare(int w=0, int h=0) : base(w, h) { }
        public override double Area()
        {
            return Dim1 * Dim2;
        }
        //abstract class as it isn't implement perimter property
        //this means you complete parent class or add members to it
    }
    class Square:BaseSquare
    {
        public override double Perimter{ get { return Dim1 * 4; }}
        // implementing Area() is optional as it is implemented in  the base class
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D06
{
    class Point3D:Point
    {
        public int Z { get; set; }
    }
    internal class Point:IComparable<Point>
    {
        public int X { get; set; }
        public int Y { get; set; }

        public int CompareTo(Point? other)
        {
            if (other == null) return 1;
            if (X == other.X) return Y.CompareTo(other.Y);
            return X.CompareTo(other.X);
        }

        public override bool Equals(object o)//base class
        {
            #region UnsafeCasting
            //Point obj = (Point)o;//derived from base
            //but this is n't safe -->o=null-->?? o=string ??--->Unhandled exceptions 
            #endregion
            #region SafeCasting
            //we have 2 ways ,in 2 ways no exception throw
            #region Way1
            //Point obj=default;
            //if (o is Point)//return true if you can cast o to Point
            //{
            //    obj = (Point)o;
            //    if (obj == null) return false;
            //    return (obj.X == X && obj.Y == Y);
            //}
            ////better syntax:from c# 6
            ////if(o is Point obj)//if true cast o to obj
            ////{
            ////    if (obj == null) return false;
            ////    return (obj.X == X && obj.Y == Y);
            ////} 
            #endregion
            #region Way2
            Point obj = o as Point;//if o can be casted to Point cast it to obj,otherwise put null in obj
            if (obj == null) return false;
            //what if o is a child from Point ????
            //in this case casting occuer however it shouldn't occur 
            if (obj.GetType() != this.GetType()) return false;
            if (ReferenceEquals(this, obj)) return true;//improve performance
            //if 2 objects have the same identity then they are equals
            return (obj.X == X && obj.Y == Y);
            #endregion
            #endregion
        }
        public override string ToString()
        {
            return $"{X}::{Y}";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D06
{
    internal class Helper
    {
        #region Generic method in non-generic class
        public static void SWAP<T>(ref T x, ref T Y)
        {
            T temp = Y;
            Y = x;
            x = temp;
        } 
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D06
{
    internal class TypeA
    {
        public int A { get; set; }
        public TypeA(int _A=0) { A = _A; }
        public void SBindShow() { Console.WriteLine("I am Base"); }
        internal virtual void DBindShow() { Console.WriteLine($"Base{A}"); }

    }
    class TypeB:TypeA
    {
        public int B { get; set; }
        public TypeB(int _A=0,int _B=0) : base(_A) { B = _B; }
        public new void SBindShow() { Console.WriteLine("I am Derived"); }
        internal override void DBindShow() { Console.WriteLine($"Derived{B}"); }

    }
    class TypeC:TypeB
    {
        public int C { get; set; }
        public TypeC(int _A=0,int _B=0,int _C = 0) : base(_A, _B) { C = _C; }
        internal override void DBindShow(){Console.WriteLine($"TypeC {A}::{B}::{C}");}
    }
    class TypeD:TypeC
    {
        //internal new void DBindShow() { Console.WriteLine("TypeD"); }//Statically Binded
        internal new virtual void DBindShow() { Console.WriteLine("TypeD"); }//Dynamically Binded
        //you can access it only by obj of TypeD 
        //no relation between this function and DBindShow in TypeC
    }
    class TypeE:TypeD
    {
        internal override void DBindShow() { Console.WriteLine("TypeE"); }
        //override TypeD.DBindShow()
    }
}

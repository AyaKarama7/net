﻿namespace D06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region RefrenceTypeEquality
            //Point p1 = new Point() { X = 5, Y = 10 };
            //Point p2 = new Point() { X = 5, Y = 10 };
            //Point p3 = p1;
            //Point p4 = default;
            //Point3D p5 = new Point3D() { X = 5, Y = 10, Z = 6 };
            //if (p1.Equals(p2) && p1 == p3) Console.WriteLine("Equals");
            //else Console.WriteLine("Not Equals");
            //if (p1.Equals(p4)) Console.WriteLine("Equals");//null
            //else Console.WriteLine("Not Equals");
            //if (p1.Equals("P2")) Console.WriteLine("Equals");//string
            //else Console.WriteLine("Not Equals");
            //if (p1.Equals(p5)) Console.WriteLine("Equals");//child
            //else Console.WriteLine("Not Equals");
            #endregion

            #region ValueTypeEquality
            //int x = 5;
            //Console.WriteLine(ReferenceEquals(x, x));//false , but it should be true???
            //first compiler take x and store it in heap as o1 with an identity id1
            //then compiler take x and store it in heap as o1 with an identity id2
            //RefrenceEquals compare idetities and id1!=id2 
            //this why RefrenceEquals is not suitable for value type equality
            //ValueTypeEquality v1 = new ValueTypeEquality() { X = 5, Y = 10 };
            //ValueTypeEquality v2 = new ValueTypeEquality() { X = 5, Y = 10 };
            //ValueTypeEquality v3 = v1;
            //ValueTypeEquality v4 = default;
            //if(v1.Equals(v2)) Console.WriteLine("Equals");//normal
            //else Console.WriteLine("Not Equals");
            //if (v1.Equals(v4)) Console.WriteLine("Equals");//null
            //else Console.WriteLine("Not Equals");
            //if (v1.Equals("v2")) Console.WriteLine("Equals");//string
            //else Console.WriteLine("Not Equals");
            #endregion

            #region Inheritence&VirtualFunction
            //Child c = new Child(2,3,4);
            //Console.WriteLine(c.product());
            ////Console.WriteLine(c.base.product());not valid in c#
            ////base keyword used only inside derived class

            //TypeA BaseRef = new TypeA();
            //BaseRef.SBindShow();//Base
            //BaseRef.DBindShow();//Base

            //TypeB DerivedRef = new TypeB();
            //DerivedRef.SBindShow();//Derived
            //DerivedRef.DBindShow();//Derived

            //BaseRef = new TypeB();//see the base part inside derived part
            ////Ref to base=Derived
            //BaseRef.A = 6;
            //BaseRef.SBindShow();//Base
            ////All statically Binded methodes (non-virtual) compiler bind call base on refrence type not object type
            //BaseRef.DBindShow();//Derived
            ////All dynamically Binded methodes (virtual) compiler bind call base on object type

            //BaseRef = new TypeC();
            //DerivedRef = new TypeC();
            //BaseRef.DBindShow();//TypeC
            //DerivedRef.DBindShow();//TypeC 
            #endregion

            #region Abstract
            //Person p = new Person("Aya", "Ahmed");can't create instance from abstract class 
            #endregion

            #region Generic method in non generic class
            //int x = 1, y = 2;
            ////Helper.SWAP(ref x, ref y);//correct
            //Helper.SWAP<int>(ref x, ref y);//correct,Explicity defining T
            ////only in the case of generic method (not class/struct/interace case) 
            ////compiler can detect datatype from input
            ////jet compiler is responsible for assigning correct datatypes
            //Console.WriteLine($"x:{x}");
            //Console.WriteLine($"y:{y}");

            //Point p1 = new Point() { X = 12, Y = 15 };
            //Point p2 = new Point() { X = 2, Y = 5 };
            //Helper.SWAP(ref p1, ref p2);
            //Console.WriteLine($"P1:{p1}");
            //Console.WriteLine($"P2:{p2}"); 
            #endregion

            #region GenericUriParser method in generic class
            int x = 1, y = 2;
            Helper1<int>.SWAP(ref x, ref y);
            Console.WriteLine($"x:{x}");
            Console.WriteLine($"y:{y}");

            Point p1 = new Point() { X = 12, Y = 15 };
            Point p2 = new Point() { X = 2, Y = 5 };
            Helper1<Point>.SWAP(ref p1, ref p2);
            Console.WriteLine($"P1:{p1}");
            Console.WriteLine($"P2:{p2}");

            Point[] p = new Point[] { p1, p2 };
            Helper1<Point>.Bsort(p);
            Console.WriteLine($"{p[0]}****{p1}");

            #endregion


        }
    }
}
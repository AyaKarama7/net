﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D06
{
    internal class Helper1<T>where T:IComparable<T>
    {
        //public static int Sum(T x, T y) { return x + y; }can't be implemented using generix
        public static void Bsort(T[]arr)
        {
            for (int i = 0; i < arr?.Length; i++)
                for (int j = 0; j < arr?.Length - i - 1; j++)
                    if (arr[j].CompareTo(arr[j + 1])>0) SWAP(ref arr[j], ref arr[j + 1]);
        }
        public int SearchArray(T[]arr,T val)
        {
            for (int i = 0; i < arr?.Length; i++)
                if (arr[i].Equals(val)) return i;
            return -1;
        }
        public static void SWAP(ref T x,ref T y)
        {
            T temp = y;
            y = x;
            x = temp;
        }
    }
}

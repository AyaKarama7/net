﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D06
{
    class Child:Parent
    {
        public int Z { get; protected set; }
        public Child(int _x,int _y,int _z):base(_x,_y)
        {
            Z = _z;
        }
        public new int product()//new is non important in the case of non virtual function 
        {
            //new means I override a function exist in parent
            // it hide the original function
            //return X * Y * Z;
            return base.product() * Z;
        }
        public override string ToString()
        {
            return $"{X}::{Y}::{Z}";
        }
    }
    internal class Parent
    {
        public int X { get; protected set; }
        public int Y { get; protected set; }
        public Parent(int _x,int _y)
        {
            X = _x;
            Y = _y;
        }
        public int product()
        {
            return X * Y;
        }
        public override string ToString()
        {
            return $"{X}::{Y}";
        }

    }
}

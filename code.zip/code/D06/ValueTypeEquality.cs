﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D06
{
    struct ValueTypeEquality
    {
        public int X { get; set; }
        public int Y { get; set; }
        public override bool Equals(object o)//base class
        {
            if (o is ValueTypeEquality)
            {
                ValueTypeEquality obj = (ValueTypeEquality)o;
                return (obj.X == X && obj.Y == Y);
            }
            return false;
        }
    }
}

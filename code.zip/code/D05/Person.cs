﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D05
{
    internal class Person
    {
        public string FName { get; set; }
        public string LName { get; set; }
        public static explicit operator Person(Employee e)
        {
            var NameList = e.Name.Split(' ');
            return new Person() { FName = NameList[0], LName = NameList[1] };
        }

    }
}

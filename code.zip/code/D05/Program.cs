﻿using System;
using Model;
namespace D05
{
    class TypeD:TypeA
    {
        public TypeD()
        {
            y = 1;//protected can be accessec by inheritence
            w = 2;//public accessed anywhere
            v = 3;//not in te same assembly file but there are inheritence
            //u = 5; not in te same assembly
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Access Modifiers
            //TypeA obj = new TypeA();
            //obj.w = 1;//public
            //          //obj.x;private
            //          //obj.y;protected with no inheritence
            //          //obj.z;internal but we are outside the assemply file
            //          //obj.v;no inheritence&not the same assembly file 
            #endregion

            #region Ctor
            //car c1 = new car();//default still used
            //car c2 = new car(1, "AbA");//after defining user defined ctor
            //Cars c3;//zero bytes allocated in heap
            ////c3 = new Cars();can't be used after generating user-defined ctor
            ////new->allocate and intialize object in heap
            ////new->call user defined ctor if exist
            ////new->assign refrence to object
            ////attributes already given intial values in heap
            //c3 = new Cars(1, "ABC", 40);
            //Cars c4 = new Cars();//as I gave derfault values to user defined ctor 
            //Console.WriteLine(c3);//call ToString automatically
            //Console.WriteLine(c4);
            #endregion

            #region copyCtor
            //Console.WriteLine(c3.GetHashCode());
            //Console.WriteLine(c4.GetHashCode());

            ////c4 = c3;//c4 points to c3 the same data and hash code

            ////c4 = new Cars(c3);//use copy ctor ,the same data , but new obj with diffrent place and identity
            //c4 = (Cars)c3.Clone();//explicit casting ,the same data , but new obj with diffrent place and identity

            ////c4 become unreachable object(garbage)
            ////removed by garbage collector in heap

            //Console.WriteLine(c4.GetHashCode());
            #endregion

            #region StaticCtor&StaticClass
            ////Utality u1 = new Utality(10, 20);
            ////Utality u2 = new Utality(30, 40);
            //Console.WriteLine(Utality.CircleArea(1));
            //Console.WriteLine(Utality.cm2Inch(10));//called static fun without object 
            #endregion

            #region StaticWithSingleTonDesignPattern
            GCard obj1 = GCard.singleobj;
            GCard obj2 = GCard.singleobj;
            Console.WriteLine($"{obj1.GetHashCode}::{obj1.Data}");
            Console.WriteLine($"{obj2.GetHashCode}::{obj2.Data}");
            #endregion

            #region OperatorOverloading
            Complex c1 = new Complex() { Real = 10, Img = 15 };
            Complex c2 = new Complex() { Real = 20, Img = 25 };
            Complex c3 = default, c4 = default;
            c3 = c1 + c2;
            c4 = c3 + 7;
            c2 += c1;
            c3 = -c2;
            c1++;
            ++c2;
            Console.WriteLine(c1);
            Console.WriteLine(c2);
            Console.WriteLine(c3?.ToString());
            Console.WriteLine(c4?.ToString());
            if (c2 > c3) Console.WriteLine("C2 > C3");
            else Console.WriteLine("C3 > C2");
            int num1 = c1;//implicit
            int num2 = (int)c1;//explicit
            string s = (string)c1;//explicit
            Console.WriteLine(num1);
            Console.WriteLine(num2);
            Console.WriteLine(s);
            Employee e = new Employee() { Name = "Aya Ahmed", Id = 1, Salary = 15000 };
            Person p = (Person)e; 
            #endregion

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D05
{
    struct car
    {
        int id;
        string model;
        public car(int _Id,string _Model)
        {
            id = _Id;
            model = _Model;
        }
    }
    internal class Cars:IComparable,ICloneable
    {
        int id;
        string model;
        int currentSpeed;
        public Cars(int _Id=1,string _Model="AA",int _cSpeed=60)
        {
            id = _Id;
            model = _Model;
            currentSpeed = _cSpeed;
        }
        public Cars(int _id,int _cSpeed):this(_id,"ABA",_cSpeed){ }//ctor chaning
        public Cars(Cars oldc)//copy ctor 
        {
            id = oldc.id;
            model = oldc.model;
            currentSpeed = oldc.currentSpeed;
        }
        public int Id { get => id; set => id = value; }
        public string Model { get => model; set => model = value; }
        public int CurrentSpeed { get => currentSpeed; set => currentSpeed = value; }
        public override string ToString()
        {
            return $"{id}::{model}::{currentSpeed}.";
        }
        public int CompareTo(object? obj)
        {
            Cars Right = (Cars)obj;
            return currentSpeed.CompareTo(Right.currentSpeed);
        }

        public object Clone()
        {
            return new Cars(this);
            //return new Cars(id, model, currentSpeed);
        }
    }
}

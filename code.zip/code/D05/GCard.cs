﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D05
{
    internal class GCard
    {
        public int Data { get; protected set; }
        GCard(int data)
        {
            Data = data;
            Console.WriteLine("Private Ctor to prevent any one to create objects only developer");
        }
        //public static GCard singleObj;//default value=null,static to use in GetCard()
        ////thread safe version from singleTon(more efficient)
        //static GCard()
        //{
        //    singleObj = new GCard(12345);
        //}
        //public static GCard GetCard()//singleTon design pattern princible
        //{
        //    //if (singleObj == null) singleObj = new GCard(12345);
        //    return singleObj;
        //}
        //all previous in one line
        public static GCard singleobj { get; } = new GCard(12345);//readonly field
        //before the first implemrntation of class singleobj given value
        //evrey time you allocate a new obj the intial value returned 
        //equal the previous code
        public void DoSomeWork()
        {
            Console.WriteLine("Processing");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D05
{
    internal static class Utality
    {
        //public int X { get; set; }
        //public int Y { get; set; }
        //public Utality(int _X,int _Y)
        //{
        //    X = _X;
        //    Y = _Y;
        //    //pi = (int)3.14;//will be declared with evrey new obj so this is not the best place for it
        //    Console.WriteLine("Object Ctor");
        //}
        static Utality()
        {
            Console.WriteLine("Static Ctor");
            pi = 3.14;//the best place
        }
        public static double cm2Inch(double cm)
        {
            return cm / 2.54;
        }
        public static double Inch2cm(double Inch)
        {
            return Inch * 2.54;
        }
        static double pi;//static to be accessed by static fun
        public static double Pi { get { return pi; } }//static attribute
        public static double CircleArea(double r)
        {
            return pi * r * r;
        }
    }
}

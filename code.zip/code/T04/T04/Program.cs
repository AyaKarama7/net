﻿int x = int.Parse(Console.ReadLine());
Console.WriteLine(x);

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class TypeA
    {
        //default access modifier is private
        int x;//private by default
        private protected int u;
        protected int y;//the class and its childeren whether they are in the same assemply file or not canuse it
        internal int z;//can be accessed over the assemply file
        protected internal int v;
        public int w;//whole solution
        public override string ToString()
        {
            return ($"{v}::{w}::{x}::{y}::{z}.");
        }

    }
}

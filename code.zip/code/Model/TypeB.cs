﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    internal class TypeB
    {
        public TypeB()
        {
            TypeA o1 = new TypeA();
            o1.w = o1.z = 1;//can access public & internal over the same assemply file
            o1.v = 2;//the same assembly file
            //o1.u;no inheritence
        }
    }
    class TypeC:TypeA
    {
        public TypeC()
        {
            this.z = 1;//can access internal as it in the same assemply file with A
            this.y = 2;//can access protected as it inherit from A
            w = 3;//this.w=3 as w is public
            v = 4;//inheritence
            u = 5;//inheritence
        }
    }
}

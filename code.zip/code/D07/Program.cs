﻿using System;
using System.Collections;
using System.Collections.Generic;
namespace D07
{
    internal class Program
    {
        public static int SumArray(ArrayList a)
        {
            int sum = 0;
            for (int i = 0; i < a?.Count; i++)
                sum += (int)a[i];//explicit unsafe casting +unboxing
            return sum;
        }
        public static int SumList(List<int>L)
        {
            int sum = 0;
            for (int i = 0; i < L?.Count; i++) sum += L[i];//implicit safe casting without unboxing
            return sum;
        }

        public delegate int StringFunctionsDelDT(string);
        static void Main(string[] args)
        {
            #region Disadvantages of using non-generic/system object collections
            //ArrayList alist = new ArrayList();
            //alist.Add(1);//boxing
            //alist.Add(3);
            //alist.Add(3);
            //alist.Add(2);
            //alist.Add("8");//complier can't check type safety,all is object
            //alist.AddRange(new int[] { 4, 5, 6, 7 });
            //alist.Remove(3);//remove the first element = 3
            //for (int i = 0; i < alist?.Count; i++) Console.Write($"{alist[i]} ");
            //Console.WriteLine();
            ////Console.WriteLine(Sum(alist));unhandled exception as alist contain string = "8" 
            #endregion

            #region List
            List<int> L = new List<int>();//more readable
            L.Add(9);
            L.Add(2);
            //L.Add("3");Compiler check & enforce Type safety during compilation
            Console.WriteLine($"ListSum={SumList(L)}");
            Console.WriteLine($"ListCount={L.Count}");//2-->As you add 2 elements 
            Console.WriteLine($"ListCapacity={L.Capacity}");
            //4->As the compiler increase the capacity of list to Capcity*2
            //At first if Capcity =0 after adding first element it become 4
            //then you add until reach capacit--> size=4 capacity=4
            L.AddRange(new int[] { 3, 4 });
            Console.WriteLine($"ListCount={L.Count}");
            Console.WriteLine($"ListCapacity={L.Capacity}");
            //After that if you add -->size=5 capacity=8-->(4*2)
            L.Add(5);
            Console.WriteLine($"ListCount={L.Count}");
            Console.WriteLine($"ListCapacity={L.Capacity}");
            //the time here is consumed by overhead but it isn't to big as every time i add i multiply by 2
            //you can access only element in the range of size not capacity
            //size=5,capacity=8 , L[4]-->valid , List[6]-->not valid
            //you can remove capacity you don't need
            L.TrimExcess();
            Console.WriteLine($"ListCount={L.Count}");
            Console.WriteLine($"ListCapacity={L.Capacity}");
            L.Add(6);
            Console.WriteLine($"ListCount={L.Count}");
            Console.WriteLine($"ListCapacity={L.Capacity}");
            L.RemoveAt(0);//size=size-1,capacity=capacity,work by shefting,remove element at index 1
            for (int i = 0; i < L?.Count; i++) Console.Write($"{L[i]} ");
            Console.WriteLine("");
            #endregion

            #region Dictionary
            Dictionary<string, long> PhoneBook = new Dictionary<string, long>();//<key,value>
            PhoneBook.Add("ABC", 123);
            PhoneBook.Add("XYZ", 456);
            PhoneBook.Add("PWV", 789);

            //PhoneBook.Add("XYZ", 342);unhandled exception , dublicated key
            //solution 1:Update by indexer
            PhoneBook["XYZ"] = 342;
            //solution 2:handle exception
            if (!PhoneBook.TryAdd("XYZ", 342)) PhoneBook["XYZ"] = 342;
            if (PhoneBook.ContainsKey("XYZ")) PhoneBook["XYZ"] = 342;
            PhoneBook["DEF"] = 777;//Add

            Console.WriteLine($"{PhoneBook["XYZ"]}");//get
            //Console.WriteLine($"{PhoneBook["abc"]}");unhandled exception,not found key
            //Solution:handle exception
            if (PhoneBook.ContainsKey("abc")) Console.WriteLine($"{PhoneBook["abc"]}");
            else Console.WriteLine("NF");
            if (PhoneBook.TryGetValue("abc", out long v)) Console.WriteLine(v);
            else Console.WriteLine("NF");

            foreach (KeyValuePair<string, long> p in PhoneBook)
                Console.WriteLine($"{p.Key}::{p.Value}");
            #endregion

            //step0:declare pointer to function
            StringFunctionsDelDT ptr;
            //step1:intialize pointer 
            ptr = new StringFunctionsDelDT(StringFunctions.GetLenght);
            //step2:Access data using ptr
            int R = ptr.Invoke("ABC");
            Console.WriteLine("R");

            //ptr points to another fun
            ptr = new StringFunctionsDelDT(StringFunctions.GetUpChar);
            R = ptr.Invoke("XaYb");

            //ptr = new StringFunctionsDelDT(StringFunctions.GetFullName);


        }
        class StringFunctions
        {
            public static int GetLenght(string Str) { return Str?.Length ?? -1; }
            //(string)return int;
            public char Ch { get; set; }
            internal int GetCharNum(String Str)
            {
                int Coutner = 0;
                for (int i = 0; i < Str?.Length; i++)
                    if (Str[i] == this.Ch) Coutner++;
                return Coutner;
            }
            //(string)return int;
            public static int GetFullName(string FName, string LName) { return FName.Length + LName.Length; }
            //(string,string)return int;
            public static int GetUpChar(string Str)
            {
                int Coutner = 0;
                for (int i = 0; i < Str?.Length; i++)
                    if (Char.IsUpper(Str[i])) Coutner++;
                return Coutner;
            }
            //(string)return int;
        }
    }
}
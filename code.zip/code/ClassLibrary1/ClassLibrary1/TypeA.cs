﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    struct TypeA
    {
        int x;//private
        internal int y;//the same project
        public int z;
        public void print()
        {
            Console.WriteLine($"x={x}.");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace D04
{
    internal class Program
    {
       
        static void Main(string[] args)
        {
            #region object intializer
            Employees e = new Employees();
            e.ID = 101;
            e.Name = "Aya";
            e.Salary = 20000;
            //you can use syntax suger rule called object intializer instead
            Employees E = new Employees() { ID = 102, Name = "Ahmed", Salary = 20000 }; 
            #endregion


        }
    }
}

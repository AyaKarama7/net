﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static D04.Program;

namespace D04
{
    struct Employees
    {       
        int id;
        string name;
        decimal salary;
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        public string Name { get { return name; } internal set { name = value; } }
        public decimal Salary { get; set; }//Automatic property
        //compiler generate hidden attribute and encapsulate it using public property
        //automatically implement get and set
        public decimal TaxRate { get; }
        public override string ToString()
        {
            return ($"{id}::{name}::{salary}.");
        }
    }
}

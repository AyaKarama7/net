﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D08
{
    struct Location
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Z { get; set; }
        //struct doesn't contain != operator so we implement it
        public static bool operator !=(Location a, Location b) => (a.X != b.X) || (a.Y != b.Y) || (a.Z != b.Z);
        // you should also implement == as operators implented in pairs (>,<) (==,!=)...
        public static bool operator ==(Location a, Location b) => (a.X == b.X) && (a.Y == b.Y) || (a.Z == b.Z);
        public override string ToString()
        {
            return $" X={X}, Y={Y}, Z={Z}";
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D08
{
    internal class Player
    {
        public string Name { get; set; }
        public string Team { get; set; }
        public void Run()=>Console.WriteLine($"Player {Name} is Running...");//call back method
        public override string ToString() => $"Player Name: {Name} , Team Name: {Team}";
    }
}

﻿namespace D08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Ball ball = new Ball();
            Player P1 = new Player() { Name = "P1", Team = "T1" };
            Player P2 = new Player() { Name = "P2", Team = "T2" };
            Player P3 = new Player() { Name = "P3", Team = "T3" };
            Player P4 = new Player() { Name = "P4", Team = "T4" };
            Refree R1 = new Refree() { Name = "R1" };
            ball.BallLocation = new Location() { X = 20, Y = 5, Z = 10 };
            Console.WriteLine(ball);
            //only ball location change
            //no reaction happened from Player or Refree
            //because we need to register subscribers call back method in Ball first
            ball.BallLocationChanged += new Action(P1.Run);
            ball.BallLocationChanged += P2.Run;
            ball.BallLocationChanged += P3.Run;
            ball.BallLocationChanged += P4.Run;
            ball.BallLocationChanged += R1.Look;
            ball.BallLocationChanged += () => Console.WriteLine("Anonymous Method");



        }
    }
}
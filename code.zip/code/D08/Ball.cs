﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace D08
{
    //publisher
    internal class Ball
    {
        public int ID { get; set; }
        Location ballLocation;
        internal Location BallLocation
        {
            get { return ballLocation; }
            set
            {
                if (ballLocation != value)
                {
                    ballLocation = value;
                    //Notify subscribers
                    BallLocationChanged?.Invoke();//? for type safey
                    //event will loop on the list of ptr to  fun of subsc.
                    //and call all the call back methods
                }

            }
        }
        //Create Event
        public event Action BallLocationChanged;
        public override string ToString() => $"Ball {ID} Location is {ballLocation}";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D08
{
    internal class Refree
    {
        public string Name { get; set; }
        public void Look() => Console.WriteLine($"Refree {Name} is looking...");
        public override string ToString() => $"Refree Name: {Name}";
    }
}
